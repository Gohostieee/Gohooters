

export default function about(){

	return(
		<div class="absolute overflow-hidden h-screen w-screen bg-black" data-theme="cyberpunk">




		</div>
	)
}